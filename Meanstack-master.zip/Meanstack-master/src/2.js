const Promise = require("Bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

        const config = {
        host: "127.0.0.1",
        user: "root",
        password: "nilluactiva3g",
        database: "nodejs",
      };

      let hellodb = async()=>{
          const connection= mysql.createConnection(config);
      

      await connection.connectAsync(); //promisify//connection open



        let sql = "SELECT * FROM PEOPLE";//query
        let output = await connection.queryAsync(sql);

      await connection.endAsync();//connection close
    

    console.log(output);
    return output;
};


let hellodb1 = async () => {
    const connection = mysql.createConnection(config);
  
    await connection.connectAsync();
  
    let sql = "SELECT * FROM PEOPLE WHERE ID=?";
    let output = await connection.queryAsync(sql, [01]);
  
    await connection.endAsync();
    console.log(output);
    return output;
  };


  let hellodb2 = async () => {
    const connection = mysql.createConnection(config);
  
    await connection.connectAsync();
  
    let sql = "SELECT * FROM PEOPLE WHERE ID=? AND NAME=?";
    let output = await connection.queryAsync(sql, [01, "clay"]);
  
    await connection.endAsync();
    console.log(output);
    return output;
  };





hellodb2();







