const Promise = require("bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

const config = {
    host: "127.0.0.1",
    user: "root",
    password: "nilluactiva3g",
    database: "nodejs",
  };

let addRecord = async () => {
  const connection = mysql.createConnection(config);
  await connection.connectAsync();

  // LOGIC
  let sql =
    "INSERT INTO PEOPLE (ID, NAME, CITY) VALUES (?, ?, ?)";
  let operation = await connection.queryAsync(sql, [
    "03",
    "Tony",
    "Seattle",

  ]);

  await connection.endAsync();
  return operation;
};

addRecord();