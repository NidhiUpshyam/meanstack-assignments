const Promise = require("Bluebird");
const mysql = require("mysql");

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

let readAllUser = async ()=>{
try{
    console.log("Read database");

    //connecting database using credentials

    const connection = mysql.createConnection({
        host: "127.0.0.1",
        user: "root",
        password: "nilluactiva3g",
        database: "nodejs",
      });

      await connection.connectAsync(); //promisify
      console.log("Connected");

      await connection.endAsync();
    }

    catch(err){
        console.log(err);
    }
};

readAllUser();







