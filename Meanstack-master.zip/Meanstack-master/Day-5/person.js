class Person {

    constructor() {}

    getName () {
        return "I am NodeJS, I am cool!!!";
    }

}

// exporting the class as a module
module.exports = Person;