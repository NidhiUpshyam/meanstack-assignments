class Employee {

    hello() {
        return 'I am Employee!!';
    }
}

module.exports = Employee;