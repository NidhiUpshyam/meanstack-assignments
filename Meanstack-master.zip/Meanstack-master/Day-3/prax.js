let getweather(){
    let xhr= new XMLHttpRequest();

    xhr.open("GET","https://samples.openweathermap.org/data/2.5/weather?id=2172797&appid=439d4b804bc8187953eb36d2a8c26a02")
}