function getWeather() {

  var cityName = document.querySelector('.inputValue').value;

  //  api.openweathermap.org/data/2.5/weather?q={city name}&appid={your api key}



  let url = "https://api.openweathermap.org/data/2.5/weather?appid=37d2bd6bb515b8a7c68d4b99bf2a1580&units=metric&q=" + cityName;


  let xhr = new XMLHttpRequest();
  xhr.open("GET", url);

  xhr.onload = () => {
    const refjson = JSON.parse(xhr.responseText);
    //console.log(refjson['name']);
    jsondomOperation(refjson);
  };

  xhr.send();
}



let jsondomOperation = function (refjson) {
  var item = refjson;
  let displaybox = document.querySelector(".display");
  displaybox.children[0].innerHTML = item.name;
  displaybox.children[1].innerHTML = item.main.temp;
 
}

